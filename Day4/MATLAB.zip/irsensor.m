function  irOut  = irsensor( k, d )

    irOut = k(1)./d + k(2);

end

