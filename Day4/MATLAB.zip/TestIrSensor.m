%% Test irSensor
clear
clc
A = load('log.txt');

k = [16,10];
d_x_data2 = linspace(0.065,100,size(A,1));

d_x_data = [0.1524 0.1758 0.1975 0.2222 0.2424 0.2667 0.2909 0.3137 0.3333 0.3636 0.3810 0.4103 0.4571 0.4848 0.5 0.5333 0.5517 0.6154 0.6400 0.6957 0.7272 0.7619 0.8000 0.8421 0.8889];


%plot(Ir_y_data);
%xlim([0 50])
%ylim([0 265])

x = lsqcurvefit(@irsensor, k, d_x_data, Ir_y_data);

times = linspace(d_x_data(1), d_x_data(end));
plot(d_x_data,Ir_y_data,times,fun(x,times))
xlim([-2 10]);
ylim([0 265]);


